(function () {
  // Theme: persisted in localStorage, defaults to dark (terminal) theme
  var root = document.documentElement;
  var saved = localStorage.getItem('umd-theme');
  if (saved) root.setAttribute('data-theme', saved);

  function currentTheme() {
    return root.getAttribute('data-theme') === 'light' ? 'light' : 'dark';
  }

  function paintToggle(btn) {
    if (!btn) return;
    btn.textContent = currentTheme() === 'light' ? '☾' : '☀';
    btn.setAttribute('aria-label', 'Switch to ' + (currentTheme() === 'light' ? 'dark' : 'light') + ' theme');
  }

  document.addEventListener('DOMContentLoaded', function () {
    var toggle = document.querySelector('.theme-toggle');
    paintToggle(toggle);
    if (toggle) {
      toggle.addEventListener('click', function () {
        var next = currentTheme() === 'light' ? 'dark' : 'light';
        if (next === 'dark') root.removeAttribute('data-theme');
        else root.setAttribute('data-theme', 'light');
        localStorage.setItem('umd-theme', next);
        paintToggle(toggle);
      });
    }

    // Mobile menu
    var menuBtn = document.querySelector('.menu-toggle');
    var nav = document.querySelector('nav.pair-nav');
    if (menuBtn && nav) {
      menuBtn.addEventListener('click', function () {
        nav.classList.toggle('open');
      });
    }

    // Highlight active nav pill by current page
    var here = (location.pathname.split('/').pop() || 'index.html');
    document.querySelectorAll('.nav-pill').forEach(function (pill) {
      var href = pill.getAttribute('href');
      if (href === here || (here === '' && href === 'index.html')) {
        pill.classList.add('active');
      }
    });
  });
})();
